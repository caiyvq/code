#ifndef ALLOCATOR
#define ALLOCATOR

#define BlockSize 4096

#include <iostream>
#include <random>
#include <vector>
#include<xtr1common>
#include <climits>
#include <cstddef>

template<class T>
class Alloc
{
public:


        //member types
        typedef T value_type;
        typedef T* pointer;
        typedef const T* const_pointer;
        typedef T& reference;
        typedef const T& const_reference;
        typedef std::size_t          size_type;
        typedef ptrdiff_t       difference_type;
        typedef std::true_type propagate_on_container_move_assignment;
        typedef std::true_type is_always_equal;
 /*       template< class U >
       struct rebind
        {
            typedef std::allocator<U> other;
        };*/

        //member functions
        Alloc()
        {
            currentBlock_ = nullptr;
            currentSlot_ = nullptr;
            lastSlot_ = nullptr;
            freeSlots_ = nullptr;
        }
        Alloc(const Alloc& alloc) 
        {
            currentBlock_ = alloc.currentBlock_;
            alloc.currentBlock_ = nullptr;
            currentSlot_ = alloc.currentSlot_;
            lastSlot_ = alloc.lastSlot_;
            freeSlots_ = alloc.freeSlots;
        }
        Alloc(Alloc&& alloc)
        {
            currentBlock_ = alloc.currentBlock_;
            alloc.currentBlock_ = nullptr;
            currentSlot_ = alloc.currentSlot_;
            lastSlot_ =alloc.lastSlot_;
            freeSlots_ = alloc.freeSlots;
        }
        ~Alloc()
        {
            slot_pointer_ curr = currentBlock_;
            while (curr != nullptr) 
            {
                slot_pointer_ prev = curr->next;
                operator delete(reinterpret_cast<void*>(curr));
                curr = prev;
            }
        }
        pointer address(reference x) const
        {
            return &x;
        }
        const_pointer address(const_reference x) const
        {
            return &x;
        }
        pointer allocate(size_type n)
        {
            if (freeSlots_ != nullptr) 
            {
                pointer result = reinterpret_cast<pointer>(freeSlots_);
                freeSlots_ = freeSlots_->next;
                return result;
            }
            else 
            {
                if (currentSlot_ >= lastSlot_)
                {
                    // Allocate space for the new block and store a pointer to the previous one
                    data_pointer_ newBlock = reinterpret_cast<data_pointer_> (operator new(BlockSize));
                    reinterpret_cast<slot_pointer_>(newBlock)->next = currentBlock_;
                    currentBlock_ = reinterpret_cast<slot_pointer_>(newBlock);
                    // Pad block body to staisfy the alignment requirements for elements
                    data_pointer_ body = newBlock + sizeof(slot_pointer_);
                    size_type bodyPadding = padPointer(body, alignof(slot_type_));
                    currentSlot_ = reinterpret_cast<slot_pointer_>(body + bodyPadding);
                    lastSlot_ = reinterpret_cast<slot_pointer_>(newBlock + BlockSize - sizeof(slot_type_) + 1);
                }
                return reinterpret_cast<pointer>(currentSlot_++);
            }
        }
        void deallocate(T* p, unsigned long long n)
        {
            if (p != nullptr) {
                reinterpret_cast<slot_pointer_>(p)->next = freeSlots_;
                freeSlots_ = reinterpret_cast<slot_pointer_>(p);
            }
        }
        size_type max_size()
        {
            size_type maxBlocks = -1 / BlockSize;
            return (BlockSize - sizeof(data_pointer_)) / sizeof(slot_type_) * maxBlocks;
        }
        template< class U, class... Args >
        void construct(U* p, Args&&... args)
        {
            new (p) U(std::forward<Args>(args)...);
        }
        template< class U > 
        void destroy(U* p)
        {
            p->~U();
        }
 /*       template< class T1, class T2 >
        bool operator==(const std::allocator<T1>& lhs)
        {
            return true;
        }
        template< class T1, class T2 >
        bool operator!=(const std::allocator<T1>& lhs)
        {
            return false;
        }*/

        //��
        union Slot_
        {
            value_type element;
            Slot_* next;
        };
        typedef char* data_pointer_;
        typedef Slot_ slot_type_;
        typedef Slot_* slot_pointer_;
        slot_pointer_ currentBlock_;
        slot_pointer_ currentSlot_;
        slot_pointer_ lastSlot_;
        slot_pointer_ freeSlots_;
};

#endif // !ALLOCATOR
