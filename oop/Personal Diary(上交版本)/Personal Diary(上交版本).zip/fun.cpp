#include"head.h"
bool compareByDate(entity a, entity b)//Order criteria for diary
{
	return a.getDate() < b.getDate();
}
void pdadd()
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************

	//new entity***************************
	entity newDiary;//create a new entity
	newDiary.setDate();
	string newText;
	getline(cin, newText);
	while (newText != ".")
	{
		newDiary.append(newText);
		newDiary.append("\n");
		getline(cin, newText);
	}
	newDiary.append(".");//the entity has been created, then determine whether it needs to be added to the diary
	int index = mydiary.find(newDiary);
	if (index>=0)//there is already an entity on that day
	{
		cout << "There is already a diary on this day, do you want to replace it? Input Y or N." << endl;
		string x;
		getline(cin, x);
		if (x == "Y")
		{
			mydiary.update(index, newDiary);
		}
	}
	else//there is not an entity yet
	{
		mydiary.pushback(newDiary);
	}
	mydiary.sort();
	//**************************************
	
	//output to diary.txt***************************
	ofstream out(path);
	vector<entity> temp = mydiary.getDiary();
	for (vector<entity>::iterator it = temp.begin(); it != temp.end(); it++)
	{
		out << it->getDate() << endl << it->getText() << endl;
	}
	mydiary.clear();
	out.close();
	// *************************************
}
void pdadd(string date)
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************

	//new entity***************************
	entity newDiary;//create a new entity
	newDiary.setDate(date);
	string newText;
	getline(cin, newText);
	while (newText != ".")
	{
		newDiary.append(newText);
		newDiary.append("\n");
		getline(cin, newText);
	}
	newDiary.append(".");//the entity has been created, then determine whether it needs to be added to the diary
	int index = mydiary.find(newDiary);
	if (index >= 0)//there is already an entity on that day
	{
		cout << "There is already a diary on this day, do you want to replace it? Input Y or N." << endl;
		string x;
		getline(cin, x);
		if (x == "Y")
		{
			mydiary.update(index, newDiary);
		}
	}
	else//there is not an entity yet
	{
		mydiary.pushback(newDiary);
	}
	mydiary.sort();
	//**************************************

	//output to diary.txt***************************
	ofstream out(path);
	vector<entity> temp = mydiary.getDiary();
	for (vector<entity>::iterator it = temp.begin(); it != temp.end(); it++)
	{
		out << it->getDate() << endl << it->getText() << endl;
	}
	mydiary.clear();
	out.close();
	// *************************************
}
void pdlist()
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************
	//list dates of all diary******************
	vector<entity> temp = mydiary.getDiary();
	for (vector<entity>::iterator it = temp.begin(); it != temp.end(); it++)
	{
		cout << it->getDate() << endl;
	}
	mydiary.clear();
	system("pause");
	//************************************
}
void pdlist(string start,string end)
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************
	//list dates in the range******************
	vector<entity> temp = mydiary.getDiary();
	for (vector<entity>::iterator it = temp.begin(); it != temp.end(); it++)
	{
		if (it->getDate() >= start && it->getDate() <= end)//judge the date
		{
			cout << it->getDate() << endl;
		}
	}
	mydiary.clear();
	//************************************
}
void pdshow()
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************
	
	//show the diary******
	string date;
	while (cin >> date)
	{
		entity temp;
		temp.setDate(date);
		int index = mydiary.find(temp);
		if (index < 0)//no entity
		{
			cout << "No diary on " << date << "." << endl;
		}
		else// an entity
		{
			cout << mydiary.getDiary()[index].getDate() << endl;
			cout << mydiary.getDiary()[index].getText().substr(0, mydiary.getDiary()[index].getText().length() - 2) << endl;
		}
	}
	mydiary.clear();
	// ***********************************
}
int pdremove()
{
	//Copy diary.txt to mydiary*************
	mydiary.copy();
	// ***********************************

	//delete on mydiary**************
	string date;
	int flag = 0;
	while (cin >> date)
	{
		entity temp;
		temp.setDate(date);
		int index = mydiary.find(temp);
		if (index < 0)//no entity
		{
			flag = -1;
		}
		else//an entity
		{
			mydiary.erase(index);
		}
		if (flag == 0)cout << "success" << endl;
		else cout << "fail" << endl;
		flag = 0;
	}

	//***********************************

	//output to diary.txt***************************
	ofstream out(path);
	vector<entity> Temp = mydiary.getDiary();
	for (vector<entity>::iterator it = Temp.begin(); it != Temp.end(); it++)
	{
		out << it->getDate() << endl << it->getText() << endl;
	}
	mydiary.clear();
	out.close();
	// *************************************
	return flag;
}