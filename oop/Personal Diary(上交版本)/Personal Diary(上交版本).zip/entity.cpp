#include"head.h"
string entity::getDate()
{
	return date;
}
string entity::getText()
{
	return text;
}
void entity::setDate()
{
	time_t now = time(0);
	tm* date = localtime(&now);
	stringstream ss;
	ss << 1900 + date->tm_year << "/" << 1+date->tm_mon << "/" << date->tm_mday;
	string temp;
	ss >> temp;
	entity::date.append(temp);
}
void entity::setDate(string date)
{
	entity::date = date;
}
vector<entity> Diary::getDiary()
{
	return diary;
}
void entity::append(string newText)
{
	text.append(newText);
}