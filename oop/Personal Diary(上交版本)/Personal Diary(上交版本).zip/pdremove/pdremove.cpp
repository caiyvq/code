#include"head.h"
Diary mydiary;

int main(int argc, char* argv[])
{
	int flag = pdremove();
	return flag;
}