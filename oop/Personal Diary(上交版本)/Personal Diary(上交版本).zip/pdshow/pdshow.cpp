#include"head.h"
Diary mydiary;

int main(int argc, char* argv[])
{
	pdshow();
	return 0;
}