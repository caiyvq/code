#include<iostream>
#include<fstream>
#include<vector>
#include<string>
#include<sstream>
#include<ctime>
#include<algorithm>
#include<cstdlib>
using namespace std;
#define path "D:\\diary.txt" //Default output document path
//class : a diary********************
class entity
{
private:
	string date;
	string text;
public:
	void setDate();
	void setDate(string date);
	string getDate();
	string getText();
	void append(string newText);
};
//*****************************

//class��all diary******************
class Diary
{
private:
	vector<entity>diary;
public:
	int find(entity newDiary);
	void copy();
	vector<entity> getDiary();
	void clear();//claer mydiary
	void update(int index, entity newDiary);//Update existing entity
	void pushback(entity newDiary);//add new entity
	void sort();//sort the diary by dates
	void erase(int index);//delete an entity
};
//*****************************

extern Diary mydiary;
void pdadd();
void pdadd(string date);
void pdlist();
void pdlist(string start,string end);
void pdshow();
int pdremove();
bool compareByDate(entity a,entity b);