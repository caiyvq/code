#include"head.h"
void Diary::update(int index, entity newDiary)
{
	diary[index] = newDiary;
}
void Diary::pushback(entity newDiary)
{
	diary.push_back(newDiary);
}
void Diary::clear()
{
	diary.clear();
}
void Diary::sort()
{
	std::sort(diary.begin(), diary.end(), compareByDate);
}
void Diary::erase(int index)
{
	diary.erase(diary.begin() + index);
}
int Diary::find(entity newDiary)
{
	int flag = 0;
	vector<entity>::iterator it;
	for (it = diary.begin(); it != diary.end(); it++, flag++)
	{
		if (newDiary.getDate() == it->getDate())
		{
			break;
		}
	}
	if (it == diary.end())
		flag = -1;
	return flag;
}
void Diary::copy()
{
	ifstream in(path);
	string date;
	while (in >> date)
	{
		string text;
		entity temp;
		temp.setDate(date);
		string x;
		getline(in, x);
		getline(in, text);
		while (text != ".")
		{
			temp.append(text);
			temp.append("\n");
			getline(in, text);
		}
		temp.append(".");
		mydiary.pushback(temp);
	}
	in.clear();
	in.close();
}