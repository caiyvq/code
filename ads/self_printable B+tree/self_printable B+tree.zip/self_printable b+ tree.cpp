#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;


struct NODE;
typedef struct NODE* node;
struct NODE
{
	int key[5];
	node kid[5];
	node dad;
	int keys;
	int kids;
	bool leaf;
};
node find(node t, int x);
bool found(node t, int x);
node insert(node t, int x);
node split(node t);
void print(node t,int max);
int main()
{
	int N, max = 0;
	cin >> N;
	node t = NULL;
	for (int i = 0; i < N; i++)
	{
		int x;
		cin >> x;
		max = (x > max) ? x : max;
		node leaf = find(t, x);
		if (found(leaf, x))
			cout << "Key " << x << " is duplicated" << endl;
		else
			t=insert(leaf, x);
	}
	print(t,max);
	return 0;
}
node find(node t, int x)//找到x可能存在的叶节点
{
	if (t == NULL)
		return t;
	else if (t->leaf)
		return t;
	else if (!t->leaf)
	{
		int index = t->keys;
		for (; index>0; index--)//不对
		{
			if (x >= t->key[index-1])
				break;
		}
		//int index = upper_bound(t->key, t->key + t->keys, x) - t->key;//可以改写吗
		return find(t->kid[index], x);
	}
}
bool found(node t, int x)//在find确定的叶节点中找x
{
	bool ret = false;
	if (t == NULL)
		ret = false;
	else
	{
		for (int i = 0; i < t->keys; i++)
		{
			if (x == t->key[i])
			{
				ret = true;
				break;
			}
		}
	}
	return ret;
}
node insert(node t, int x)//在叶节点中插值
{
	if (t == NULL)
	{
		t = (node)malloc(sizeof(struct NODE));
		t->dad = NULL;
		t->keys = 1;
		t->key[0] = x;
		t->leaf = true;
		t->kids = 0;
		t->kid[0] = NULL;//防止野指针，因为这个问题层序输出时不能及时结束
	}
	else
	{
		t->key[t->keys++] = x;
		sort(t->key, t->key + t->keys);//t->keys要减一吗
		if (t->leaf == true && t->keys == 4 || t->leaf == false && t->keys == 3)
		{
			t=split(t);//存疑
		}
	}
	node root=t->dad;
	while (root != NULL)
	{
		t = root;
		root = t->dad;
	}
	return t;//应返回根节点
}
node split(node t)
{
	if (t->dad==NULL)
	{
		node newt = (node)malloc(sizeof(struct NODE));
		t->dad = newt;
		newt->dad = NULL;
		newt->keys = 0;
		newt->leaf = false;
		newt->kids = 0;
	}
	node dad = t->dad;
	node lt = (node)malloc(sizeof(struct NODE));
	node rt = (node)malloc(sizeof(struct NODE));
	if (t->leaf)
	{
		lt->dad = rt->dad = dad;
		lt->keys = 2;
		rt->keys = 2;
		lt->key[0] = t->key[0];
		lt->key[1] = t->key[1];
		rt->key[0] = t->key[2];
		rt->key[1] = t->key[3];
		lt->kid[0] = NULL;
		rt->kid[0] = NULL;
		lt->leaf = rt->leaf = true;
		dad->key[dad->keys++] = t->key[2];
		sort(dad->key, dad->key + dad->keys);

		if (dad->kids == 0)
		{
			dad->kid[0] = lt;
			dad->kid[1] = rt;
			dad->kids = 2;
		}
		else
		{
			for (int i = dad->kids - 1; i >= 0; i--)
			{
				if (dad->kid[i] == t)
				{
					dad->kid[i] = lt;
					dad->kid[i + 1] = rt;
					break;
				}
				else
				{
					dad->kid[i + 1] = dad->kid[i];
				}
			}
			dad->kids++;
		}

		//dad->kid[dad->kids++] = rt;
		//for (int i = 0; i < dad->kids;i++)
		//{
		//	if (dad->kid[i] == t)
		//		dad->kid[i] = lt;
		//	break;
		//}
		//sort(dad->kid, dad->kid + dad->kids);
		free(t);
	}
	else
	{
		lt->dad = rt->dad = dad;
		lt->keys = 1;
		rt->keys = 1;
		lt->key[0] = t->key[0];
		rt->key[0] = t->key[2];
		lt->leaf = rt->leaf = false;
		lt->kids = 2;
		rt->kids = 2;
		lt->kid[0] = t->kid[0];
		lt->kid[0]->dad = lt;
		lt->kid[1] = t->kid[1];
		lt->kid[1]->dad = lt;
		rt->kid[0] = t->kid[2];
		rt->kid[0]->dad = rt;
		rt->kid[1] = t->kid[3];
		rt->kid[1]->dad = rt;
		dad->key[dad->keys++] = t->key[1];
		sort(dad->key, dad->key + dad->keys);

		if (dad->kids == 0)
		{
			dad->kid[0] = lt;
			dad->kid[1] = rt;
			dad->kids = 2;
		}
		else
		{
			for (int i = dad->kids - 1; i >= 0; i--)
			{
				if (dad->kid[i] == t)
				{
					dad->kid[i] = lt;
					dad->kid[i + 1] = rt;
					break;
				}
				else
				{
					dad->kid[i + 1] = dad->kid[i];
				}
			}
			dad->kids++;
		}

		//dad->kid[dad->kids++] = rt;
		//for (int i = 0; i < dad->kids;i++)
		//{
		//	if (dad->kid[i] == t)
		//		dad->kid[i] = lt;
		//	break;
		//}
		//sort(dad->kid, dad->kid + dad->kids);
		free(t);
	}
	if (dad->keys == 3)
	{
		dad=split(dad);
	}
	return dad;
}
void print(node t,int max)
{
	if (t == NULL)
		return;
	cout << "[";
	for (int i = 0; i < t->keys; i++)
	{
		if (i != 0)
			cout << ",";
		cout << t->key[i];
	}
	cout << "]";
	if(!t->leaf)
		cout<< endl;

	queue<node> q;
	for (int i = 0; i < t->kids; i++)
	{
		q.push(t->kid[i]);
	}
	while (!q.empty())
	{
		node t1 = q.front();
		q.pop();
		if (t1 == NULL)
			break;
		cout << "[";
		for (int i = 0; i < t1->keys; i++)
		{
			if (i != 0)
				cout << ",";
			cout << t1->key[i];
		}
		cout << "]";

		//if (t1 == t1->dad->kid[t1->dad->kids - 1]&&!t1->leaf)
		//	cout << endl;
		if (found(find(t1,max), max) && !t1->leaf)
			cout << endl;
		if(found(find(t1,max), max) && t1->leaf)
             break;//叶节点的子节点没有定义为NULL时需要如此判断一下才能结束
		for (int i = 0; i < t1->kids; i++)
		{
			q.push(t1->kid[i]);
		}
	}
}