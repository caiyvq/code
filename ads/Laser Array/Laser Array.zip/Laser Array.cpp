#include<iostream>
using namespace std;

const int MAXN = 200010;
long long highest;
long long lowest;
int n;
int a[MAXN];

void count(int index);
int main()
{
	cin >> n;
	//����
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	for (int i = 1; i < n; i++)
	{
		count(i);
	}
	cout << lowest << endl << highest << endl;
	return 0;
}
//��index��ʼ���ұȽϣ���ߵ��Ѿ��ȽϹ���
void count(int index)
{
	for (int i = index + 1; i <= n; i++)
	{
		if (a[i] < a[index])
			lowest++;
		if (a[i] <= a[index])
			highest++;
	}
}