#include <cstdio>
#define MAXN 300010
using namespace std;
#include<vector>
#include<algorithm>
int worthy_match(int n, int td, int ts, int A[], int B[], int match_ind[])
{
    std::sort(A+1, A + n);
    std::sort(B+1, B + n);//����
    vector<vector<int> >dp(n + 1, vector<int>(n + 1, 0));
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            // �ж��Ƿ������������
            if (abs(A[i] - B[j]) <= td && A[i] + B[j] >= ts)
            {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            }
            else
            {
                dp[i][j] = max(dp[i][j - 1], dp[i - 1][j]);
            }
        }
    }
    int i = n, j = n;
    while (i > 0 && j > 0)
    {
        if (abs(A[i] - B[j]) <= td && A[i] + B[j] >= ts && dp[i][j] == dp[i - 1][j - 1] + 1)
        {
            match_ind[i] = j;
            i--;
            j--;
        }
        else if (dp[i][j] == dp[i][j - 1])
        {
            j--;
        }
        else
        {
            i--;
        }
    }
    return dp[n][n];
}

/* Your submission will be put here. Feel free to add anything needed even if it is not a function. */

int n;
int td, ts;
int A[MAXN], B[MAXN];
int match_ind[MAXN];

int check_tmp[MAXN];
int valid_check(int n, int td, int ts, const int A[], const int B[], const int match_ind[], int num_worthy_pairs)
{
    int i, j;
    for (i = 1; i <= n; i++) {
        j = match_ind[i];
        if (j < 1 || j > n || check_tmp[j]) return -1;
        check_tmp[j] = 1;
        if (A[i] + B[j] >= ts && A[i] - B[j] <= td && B[j] - A[i] <= td) num_worthy_pairs--;
    }
    return num_worthy_pairs;
}

int main()
{
    scanf("%d%d%d", &n, &td, &ts);
    for (int i = 1; i <= n; i++) { scanf("%d", A + i); }
    for (int i = 1; i <= n; i++) { scanf("%d", B + i); }
    int num_worthy_pairs = worthy_match(n, td, ts, A, B, match_ind);
    printf("%d\n", num_worthy_pairs);
    printf(valid_check(n, td, ts, A, B, match_ind, num_worthy_pairs) ? "WA" : "OK");
    return 0;
}