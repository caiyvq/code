﻿#include <iostream>
using namespace std;
struct TREENODE;
typedef struct TREENODE* node;
struct TREENODE
{
    int height,key;
    node lt, rt;
};
node insert(int x, node t);
node ll(node t);
node rl(node t);
node lr(node t);
node rr(node t);
int get_height(node t);
int main()
{
    int N;
    cin >> N;
    node t;
    t = (node)malloc(sizeof(struct TREENODE));
    t = NULL;
    int x;
    for (int i = 0; i < N; i++)
    {
        cin >> x;
        t=insert(x, t);
    }
    cout << t->key;
    return 0;
}
int get_height(node t)
{
    if (t == NULL)return -1;
    //max(get_height(t->lt) + 1, get_height(t->rt) + 1);
    else return t->height;
}
node insert(int x, node t)
{
    if (t == NULL)
    {
        t = (node)malloc(sizeof(struct TREENODE));
        t->key = x;
        t->height = 0;
        t->lt = NULL;
        t->rt = NULL;
    }
    else if (x < t->key)
    {
        t->lt = insert(x, t->lt);
        if (t->lt->height - get_height(t->rt) == 2)
        {
            if (x < t->lt->key)
            {
                t=ll(t);
            }
            else
            {
                t=lr(t);
            }
        }
    }
    else
    {
        t->rt = insert(x, t->rt);
        if (get_height(t->lt) - t->rt->height == -2)
        {
            if (x < t->rt->key)
            {
                t=rl(t);
            }
            else
            {
                t=rr(t);
            }
        }
    }
    t->height = max(get_height(t->lt) + 1, get_height(t->rt) + 1);
    return t;
        
}
node ll(node t)
{
    node tt = t->lt;
    t->lt = tt->rt;
    tt->rt = t;
    t->height = max(get_height(t->lt) + 1, get_height(t->rt) + 1);
    tt->height = max(get_height(tt->lt) + 1, get_height(tt->rt) + 1);
    return tt;
}
node rr(node t)
{
    node tt = t->rt;
    t->rt = tt->lt;
    tt->lt = t;
    t->height = max(get_height(t->lt) + 1, get_height(t->rt) + 1);
    tt->height = max(get_height(tt->lt) + 1, get_height(tt->rt) + 1);
    return tt;
}
node rl(node t)
{
    t->rt = ll(t->rt);
    t = rr(t);
    return t;
}
node lr(node t)
{
    t->lt = rr(t->lt);
    t = ll(t);
    return t;
}
