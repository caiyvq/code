#include<iostream>
#include<map>
#include<iomanip>
using namespace std;


int main()
{
	std::cout << fixed << setprecision(2);
	map<double, double> station;
	double C, D, D_avg, P, d, allpay = 0;
	int N;
	cin >> C >> D >> D_avg >> N;
	for (int i = 0; i < N; i++)
	{
		cin >> P >> d;
		station[d] = P;
	}
	double cur_sta = 0, cur_gas = 0, can_go = 0, all_go = 0;
	map<double, double>::iterator it = station.begin();
	if (it->first > 0)
	{
		cout << "The maximum travel distance = " << all_go;
		return 0;
	}
	it++;
	while (all_go < D)
	{
		while (it != station.end()&&all_go<D&&C*D_avg > it->first - cur_sta)//���Կ���������
		{
			if (it->second <= station[cur_sta])//ֻ�ü��㹻����it����
			{
				if (can_go < it->first - cur_sta)
				{
					allpay += (((it->first - cur_sta) / D_avg) - cur_gas) * station[cur_sta];
					cur_gas = (it->first - cur_sta) / D_avg;
					can_go = cur_gas * D_avg;
				}
				cur_gas -= (it->first - cur_sta) / D_avg;
				all_go = it->first;
				can_go -= it->first - cur_sta;
				cur_sta = it->first;
				it++;
			}
			else
				it++;
		}
		if (it == station.end())//���һվ
		{
			if (C*D_avg < D - cur_sta)
			{
				all_go += C*D_avg;
				break;
			}
			else
			{
				allpay += (D - cur_sta) / D_avg * station[cur_sta];
				all_go = D;
				break;
			}
		}
		if (C*D_avg <= it->first - cur_sta)//һ·�϶��ȵ�ǰ�󣬵�ǰվ�������������һվ
		{
			allpay += (C - cur_gas) * station[cur_sta];
			cur_gas = C;
			can_go = cur_gas * D_avg;
			if (C*D_avg < it->first - cur_sta)
			{
				it--;
				if (it->first <= cur_sta)//��������һվ
				{
					all_go += C * D_avg;
					break;
				}
			}
			can_go -= it->first - cur_sta;
			cur_gas -= (it->first - cur_sta) / D_avg;
			all_go = it->first;
			cur_sta = it->first;
			it++;
		}
	}
	if (all_go < D)
	{
		std::cout << "The maximum travel distance = " << all_go;
	}
	else
	{
		std::cout << allpay;
	}
	//for (map<double, double>::iterator it = station.begin(); it != station.end(); it++)
	//{
	//	cout << it->first << "," << it->second << endl;
	//}
	return 0;
}