﻿#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

int findMin(vector<int>&v,int d)
{
	int min = -1;
	for (int i = 0; i < 3; i++)
	{
		if (v[i] < d)
			continue;
		else
		{
			min = i;
			break;
		}
	}
	return min;
}
void print(vector<int>v,int i)
{
	for (int j=i;j<v.size();j++)
	{
		cout << v[j];
		if (j != v.size() - 1)
			cout << " ";
	}
}
bool empty(vector<int>v)
{
	bool flag = true;
	for (auto i : v)
	{
		if (i != -1)
		{
			flag = false;
			break;
		}
	}
	return flag;
}
int main()
{
	int N, M;
	cin >> N >> M;

	vector<int>interMem;
	vector<int>output;
	vector<int>numbers;
	for (int i = 0; i < N; i++)
	{
		int number;
		cin >> number;
		numbers.push_back(number);
	}
	int index = 0;
	bool flag = false;
	while (!flag)
	{
		output.clear();
		for (int i = index; i<numbers.size()||!interMem.empty(); i++)
		{
			if (i < numbers.size())
			{
				if (interMem.size() < 3)
				{
					interMem.push_back(numbers[i]);
					sort(interMem.begin(), interMem.end());
					numbers[i] = -1;
				}
				else
				{
					if (output.empty())
					{
						output.push_back(interMem[0]);
						interMem[0] = numbers[i];
						sort(interMem.begin(), interMem.end());
						numbers[i] = -1;
					}
					else
					{
						int min = findMin(interMem, output.back());
						if (min == -1)
						{
							index = i;
							break;
						}
						else
						{
							output.push_back(interMem[min]);
							interMem[min] = numbers[i];
							sort(interMem.begin(), interMem.end());
							numbers[i] = -1;
						}
					}
				}
			}
			else
			{
				if (output.empty())
				{
					print(interMem,0);
				}
				else
				{
					int min = findMin(interMem, output.back());
					if (min == -1)
					{
						print(output,0);
						cout << endl;
						print(interMem, 0);
					}
					else
					{
						if (min == 0)
						{
							print(output,0);
							cout << " ";
							print(interMem,0);
							cout << endl;
						}
						else if (min == 1)
						{
							print(output,0);
							cout << " ";
							print(interMem, 1);
							cout << endl;
							cout << interMem[0];
						}
						else
						{
							print(output, 0);
							cout << " ";
							print(interMem, 2);
							cout << endl;
							cout << interMem[0]<<" "<<interMem[1];
						}
					}
				}
				interMem.clear();
				flag = true;
				output.clear();
				goto L;
			}
		}
		print(output,0);
		cout << endl;
	}
	L:
	return 0;
}
