#include<iostream>
#include<vector>
using namespace std;

int sum(int a, int b, int n)
{
	if (a + b >= n)
	{
		return a + b - n;
	}
	else if (a + b < 0)
	{
		return a + b + n;
	}
	else return a + b;
}
int main()
{
	int t;
	cin >> t;
	int cycle = 0;
	while (cycle < t)
	{
		int n;
		cin >> n;
		vector<vector<int>>A(n, vector<int>(n, 0));
		for (int i = 0; i < n; i++)
		{
			A[i][i] = 1;
		}
		vector<int> B(n, 0);
		for (int i = 0; i < n; i++)
		{
			cin >> B[i];
		}
		if (n == 1)
		{
			cout << 1 << endl;
			cycle++;
			continue;
		}
		for (int length = 1; length < n; length++)
		{
			for (int l = 0, r = l + length; l < n; l++, r=sum(r,1,n))
			{
				if (B[l] == B[r])
				{
					if (length==1)
					{
						A[l][r] = 2;
					}
					else
					{
						A[l][r] = A[sum(l, 1, n)][sum(r, -1, n)] + 2;
					}
				}
				else
				{
					A[l][r] = max(A[sum(l, 1, n)][r], A[l][sum(r, -1, n)]);
				}
			}
		}
		int max = 0;
		for (int l = 0, r = sum(l, n - 1, n); l < n; l++, r = sum(r, 1, n))
		{
			max = (max >= A[l][r]) ? max : A[l][r];
		}
		cout << max;
		if(cycle!=t-1)
			cout<< endl;
		cycle++;
	}
	return 0;
}