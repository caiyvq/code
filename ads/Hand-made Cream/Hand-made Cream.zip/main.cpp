#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
    int N, M, score1, score2;
    vector<int>bread, cream;
    cin >> N >> M;

    for (int i = 0; i < N; i++)
    {
        cin >> score1;
        bread.push_back(score1);
    }
    for (int i = 0; i < M; i++)
    {
        cin >> score2;
        cream.push_back(score2);
    }

    int maxScore = 0;
    vector<vector<int> >score(1000);
    for (int i = 0; i < 1000; i++)
    {
        score[i].resize(1000);
    }
    score[0][0]=bread[0] * cream[0];
    score[0][1] = bread[0] * cream[1];
    score[1][0] = bread[1] * cream[0];
    for (int i = 1; i < N; i++)
    {
        for (int j = 1; j < M; j++)
        {
            score[i][j] = max(max(score[i - 1][j - 1]+bread[i]*cream[j], score[i - 1][j - 1]), max(score[i][j - 1], score[i - 1][j]));
            maxScore = max(maxScore, score[i][j]);
        }
    }
    cout << maxScore;
    return 0;
}