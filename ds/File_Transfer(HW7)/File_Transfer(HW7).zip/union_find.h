#ifndef UNION_FIND_H
#define UNION_FIND_H
#define MAX 10100
extern int S[MAX];
extern int N;
#endif
void initial();
void myunion(int root1, int root2);
int find(int x);
void fun_C(int c1, int c2);
void fun_I(int c1, int c2);
void fun_S();