#include<stdio.h>
#include"union_find.h"
void myunion(int root1, int root2)//�ϲ���done by size
{
	if (S[root1] < S[root2])
	{
		S[root1] += S[root2];
		S[root2] = root1;
	}
	else
	{
		S[root2] += S[root1];
		S[root1] = root2;
	}
}
int find(int x)//�Ҹ���path compression
{
	if (S[x] <= 0)
	{
		return x;
	}
	else
	{
		return S[x] = find(S[x]);
	}
}
void fun_C(int c1, int c2)
{
	if (find(c1) == find(c2))
	{
		printf("yes\n");
	}
	else
	{
		printf("no\n");
	}
}
void fun_I(int c1, int c2)
{
	myunion(find(c1), find(c2));
}
void fun_S()
{
	int cnt = 0;
	for (int i = 1; i <= N; i++)
	{
		if (S[i] <= 0)
		{
			cnt++;
		}
	}

	if (cnt == 1)
	{
		printf("The network is connected.");
	}
	else
	{
		printf("There are %d components.", cnt);
	}
}
void initial()
{
	for (int i = 1; i <= N; i++)
	{
		S[i] = -1;
	}
}