﻿/*Input Sample 1
5
C 3 2
I 3 2
C 1 5
I 4 5
I 2 4
C 3 5
S

Input Sample 2
5
C 3 2
I 3 2
C 1 5
I 4 5
I 2 4
C 3 5
I 1 3
C 1 5
S

*/

#define  _CRT_SECURE_NO_WARNINGS//属性中把sdl改为否可去掉这行
#include<stdio.h>
#include"union_find.h"
int S[MAX];
int N;
int main()
{
	initial();
	scanf("%d\n", &N);
	char op;
	int c1, c2;
	op = getchar();//getchar和scanf有差别
	while (op != 'S')
	{
		scanf("%d %d", &c1, &c2);
		if (op == 'I')
		{
			fun_I(c1, c2);
			//printf("1\n");
		}
		else if (op == 'C')
		{
			fun_C(c1, c2);
			//printf("0\n");
		}
		op = getchar();
	}
	fun_S();
	return 0;
}