﻿#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<math.h>
#define MAX 1100
int array[MAX], array_cbst[MAX], size;
void ptr();
void sort();
void cbst_build(int left, int right,int post);//post: position of current node
int get_n(int N);
int main()
{
	int N;
	scanf("%d", &N);
	size = N;
	for (int i = 1; i <= N; i++)
	{
		scanf("%d", &array[i]);
	}

	sort();
	int left = 1, right = N, post = 1;
	cbst_build(left, right, post);
	ptr();
	
	return 0;
}
void ptr()
{
	for (int i = 1; i <= size; i++)
	{
		if (i == 1)
		{
			printf("%d", array_cbst[i]);
		}
		else
		{
			printf(" %d", array_cbst[i]);
		}
	}
}
void sort()
{
	int temp=-1,index=1;
	for (int i = 1; i <= size; i++)
	{
		index = i;
		for (int j = i + 1; j <= size; j++)
		{
			if (array[index] > array[j])
			{
				index = j;
			}
		}
		temp = array[index];
		array[index] = array[i];
		array[i] = temp;
	}
}
int get_n(int N)
{
	int n=0;
	while (pow(2, n + 1) <= N)
	{
		n++;
	}
	return n;
}
void cbst_build(int left, int right,int post)
{
	if (left > right)
	{
		return;
	}
	else if (left == right)
	{
		array_cbst[post] = array[left];
		return;
	}
	else//find root
	{
		int root, N = right - left + 1, n = get_n(N), k = N - pow(2, n);//N:number of elements; N=2^n+k
		if (k < pow(2,n-1))//left tree is not full
		{
			root = left + pow(2, n - 1) + k;//left nodes:2^(n-1)+k; right nodes:2^(n-1)-1
		}
		else//left tree is full
		{
			root = left + pow(2, n) - 1 ;//left nodes:2^n-1; right nodes:k
		}
		cbst_build(left, root - 1, 2 * post);
		cbst_build(root + 1, right, 2 * post + 1);
		array_cbst[post] = array[root];
		return;
	}
}