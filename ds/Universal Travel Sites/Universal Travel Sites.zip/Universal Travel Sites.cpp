﻿#include<iostream>
#include<unordered_map>
using namespace std;
#define MAX 510
#define INF 999999

unordered_map<string, int>l1;
unordered_map<int, string>l2;
int N;
int M[MAX][MAX];
int used[MAX];

int findFlow(string s, string t, int f);
int maxFlow(string s,string t);

int main()
{
	string s, t;
	string u, v;
	int e;
	cin >> s >> t >> N;
	for (int i = 0; i < N; i++)
	{
		cin >> u >> v >> e;
		if (l1.find(u) == l1.end())
		{
			l1[u] =(int)l1.size();
		}
		if (l1.find(v) == l1.end())
		{
			l1[v] = (int)l1.size();
		}
		M[l1[u]][l1[v]] = e;
	}
	for (auto i:l1)
	{
		l2[i.second] = i.first;
	}//初始化

	cout << maxFlow(s, t);
	return 0;
}
int findFlow(string s, string t, int f)//找一条通路，并返回这条路可以经过的最大流
{
	if (s == t)
	{
		return f;//某条路径可以通过的最大流
	}
	int minFlow = 0;
	for (int i = 0; i < N; i++)
	{
		if (M[l1[s]][i] > 0 && !used[i])
		{
			used[i] = 1;
			minFlow = findFlow(l2[i], t, min(f, M[l1[s]][i]));//min函数更新当前路径可以通过的最大流
			if (minFlow > 0)
			{
				M[l1[s]][i] -= minFlow;
				M[i][l1[s]] += minFlow;//更新边容量
				return minFlow;
			}
		}
	}
	return 0;//没有找到s到t的路径返回0
}

int maxFlow(string s, string t)
{
	int flow = 0, f = findFlow(s, t, INF);
	while (f!=0)
	{
		for (int i = 0; i < MAX; i++)
		{
			used[i] = 0;
		}
		flow += f;
		f = findFlow(s, t, INF);
	}
	return flow;
}