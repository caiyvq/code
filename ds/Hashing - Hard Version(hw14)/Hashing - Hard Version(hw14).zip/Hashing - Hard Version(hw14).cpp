﻿#include<stdio.h>
#include<stdio.h>
/*思路：
拓扑排序，用最小堆储存
*/
#define MAX 1010
#define INF 999999
int N;
int G[MAX][MAX];
struct minheap
{
	int size;
	int H[MAX];
}heap;
int degree[MAX];
int ht[MAX];

int isempty();
int del();
void insert(int n);
int main()
{
	scanf("%d\n", &N);
	heap.size = 0;
	heap.H[0] = -1;
	for (int i = 0; i < N; i++)
	{
		scanf("%d", &ht[i]);
	}
	for (int i = 0; i < MAX; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			G[i][j] = -1;
		}
		degree[i] = -1;
	}//初始化
	for (int i = 0; i < N; i++)
	{
		if (ht[i] == -1)continue;
		if (ht[i] % N == i)
		{
			degree[ht[i]] = 0;
		}
		else
		{
			if (ht[i] % N > i)
			{
				degree[ht[i]] = i - ht[i] % N + N;
			}
			else
			{
				degree[ht[i]] = i - ht[i] % N;
			}
			for (int k = ht[i] % N; k != i; k = ( k + 1 ) % N)
			{
				G[ht[k]][ht[i]] = 1;
			}
		}
	}//构建图
	for (int i = 0; i < MAX; i++)
	{
		if (degree[i] == 0)
		{
			insert(i);
		}
	}
	int flag = 0;
	//int cnt = 0;
	while (!isempty())
	{
		//cnt++;
		int v = del();
		if (flag == 0)
		{
			flag = 1;
			printf("%d", v);
		}
		else
		{
			printf(" %d", v);
		}
		for (int i = 0; i < MAX; i++)
		{
			if (G[v][i] == 1)
			{
				if (--degree[i]==0)
				{
					insert(i);
				}
			}
		}
	}//拓扑排序
	//printf("\n%d", cnt);
}
int isempty()
{
	int ret = 0;
	if (heap.size == 0)
	{
		ret = 1;
	}
	return ret;
}
int del()
{
	int ret = heap.H[1]; 
	int temp = heap.H[heap.size--];
	int dad = 1, kid = dad * 2;
	while(kid<=heap.size)
	{
		if (heap.H[kid] > heap.H[kid + 1])kid++;
		if (kid <= heap.size && temp > heap.H[kid])
		{
			heap.H[dad] = heap.H[kid];
			dad = kid;
			kid = dad * 2;
		}
		else
		{
			break;
		}
	}
	heap.H[dad] = temp;
	return ret;
}
void insert(int n)
{
	int kid = ++heap.size, dad = kid / 2;
	for (; heap.H[dad] > n; kid = dad, dad = kid / 2)
	{
		heap.H[kid] = heap.H[dad];
	}
	heap.H[kid] = n;
}