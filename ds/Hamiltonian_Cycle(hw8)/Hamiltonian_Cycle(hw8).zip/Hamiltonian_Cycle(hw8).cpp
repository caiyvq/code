﻿#include<stdio.h>
#include<stdlib.h>
int main()
{
	int N, M;
	int flag;
	scanf("%d %d", &N, &M);
	int v1,v2,R[201][201]={0};
	for (int i = 0; i < M; i++)
	{
		scanf("%d %d", &v1,&v2);
		R[v1][v2] = 1;
		R[v2][v1] = 1;
	}//二维数组储存图
	int K;
	scanf("%d", &K);
	int n;
	for (int i = 0; i < K; i++)
	{
		flag = 1;
		scanf("%d", &n);
		
		int V[201]={0}, cnt[201]={0};
		for (int j = 0;j < n; j++)
		{
			scanf("%d", &V[j]);
			cnt[V[j]]++;
			if ((j < n - 1) && (cnt[V[j]] > 1))flag = 0;//错误：中途经过重复节点
		}
		if (n != N + 1)//错误：没有遍历完或有重复的，但不能排除两者都有但总数恰好为N+1个的情况
		{
			flag = 0;
		}
		if (V[0] != V[n - 1])//错误：首尾不同
		{
			flag = 0;
		}
		else
		{
			for (int j = 0; j < N; j++)
			{
				if (R[V[j]][V[j + 1]] == 0)//错误：前后节点不相连
				{
					flag = 0;
					break;
				}
			}
		}
		if (flag == 1)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}