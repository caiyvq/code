﻿#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void type1();
void type2();
void type3();

struct INFO
{
	char s[14];
	int score;
}info[10001];
int N;
int main()
{
	int M, type;
	scanf("%d %d", &N, &M);
	for (int i = 0; i < N; i++)
	{
		scanf("%s %d", info[i].s, &info[i].score);
	}
	for (int i = 0; i < M; i++)
	{
		scanf("%d", &type);
		getchar();
		printf("Case %d: %d", i + 1, type);
		switch (type)
		{
		case 1:type1(); break;
		case 2:type2(); break;
		case 3:type3(); break;
		}
	}
}
void type1()
{
	char level;
	scanf("%c", &level);
	printf(" %c\n", level);
	int array[10001], n = 0;
	for (int i = 0; i < N; i++)
	{
		if (info[i].s[0] == level)
		{
			array[n++] = i;
		}
	}
	if (n == 0)
	{
		printf("NA\n");
	}
	else
	{
		//排序
		for (int i = 0; i < n; i++)
		{
			int max = i;
			for (int j = i + 1; j < n; j++)
			{
				if (info[array[j]].score > info[array[max]].score)
				{
					max = j;
				}
				else if (info[array[j]].score == info[array[max]].score)
				{
					int k = 1;
					while (info[array[j]].s[k] == info[array[max]].s[k])
					{
						k++;
					}
					if (info[array[j]].s[k] < info[array[max]].s[k])
					{
						max = j;
					}
				}
			}
			int temp = array[max];
			array[max] = array[i];
			array[i] = temp;
		}
		//输出
		for (int i = 0; i < n; i++)
		{
			printf("%s %d\n", info[array[i]].s, info[array[i]].score);
		}
	}
}
void type2()
{
	int cnt = 0, sum = 0;
	char site[3];
	scanf("%c%c%c", &site[0], &site[1], &site[2]);
	printf(" %c%c%c\n", site[0], site[1], site[2]);
	for (int i = 0; i < N; i++)
	{
		if ((info[i].s[1] == site[0]) && (info[i].s[2] == site[1]) && (info[i].s[3] == site[2]))
		{
			cnt++;
			sum += info[i].score;
		}
	}
	if (cnt > 0)
	{
		printf("%d %d\n", cnt, sum);
	}
	else
	{
		printf("NA\n");
	}
}

void type3()
{
	char date[6];
	scanf("%c%c%c%c%c%c", &date[0], &date[1], &date[2], &date[3], &date[4], &date[5]);
	printf(" %c%c%c%c%c%c\n", date[0], date[1], date[2], date[3], date[4], date[5]);
	int nt[1000] = { 0 }, array[10001], n = 0;
	for (int i = 0; i < N; i++)
	{
		if ((info[i].s[4] == date[0]) && (info[i].s[5] == date[1]) &&
			(info[i].s[6] == date[2]) && (info[i].s[7] == date[3]) &&
			(info[i].s[8] == date[4]) && (info[i].s[9] == date[5]))
		{
			array[n++] = i;
		}
	}
	if (n == 0)
	{
		printf("NA\n");
	}
	else
	{
		//排序
		//把每个site的个数存进nt[1000]，nt[site]==numbers
		for (int i = 0; i < n; i++)
		{
			int site = (info[array[i]].s[1] - '0') * 100 + (info[array[i]].s[2] - '0') * 10 + (info[array[i]].s[3] - '0');
			nt[site]++;
		}
		//numbers从大到小排
		for (int i = 0; i < n; i++)
		{
			int siteOfMaxNt = (info[array[i]].s[1] - '0') * 100 + (info[array[i]].s[2] - '0') * 10 + (info[array[i]].s[3] - '0');
			int max = i;
			for (int j = i; j < n; j++)
			{
				int site = (info[array[j]].s[1] - '0') * 100 + (info[array[j]].s[2] - '0') * 10 + (info[array[j]].s[3] - '0');
				if (nt[site] > nt[siteOfMaxNt])
				{
					max = j;
				}
				else if (nt[site] == nt[siteOfMaxNt])
				{
					if (site < siteOfMaxNt)
					{
						max = j;
					}
				}
			}
			int temp = array[max];
			array[max] = array[i];
			array[i] = temp;
		}
		
		//输出,消除重复的
		int siteRecord[10001] = { 0 };
		for (int i = 0; i < n; i++)
		{
			int site = (info[array[i]].s[1] - '0') * 100 + (info[array[i]].s[2] - '0') * 10 + (info[array[i]].s[3] - '0');
			siteRecord[i] = site;
			for (int j = 0; j < i; j++)
			{
				if (site == siteRecord[j])
				{
					siteRecord[i] = -1;
				}
			}
		}
		for (int i = 0; i < n; i++)
		{
			if (siteRecord[i] != -1)
			{
				printf("%d %d\n", siteRecord[i], nt[siteRecord[i]]);
			}
		}
	}
}