﻿#include<stdio.h>
#define MAX 110
int N;
int before1[MAX];
int later[MAX];
int before2[MAX];
void output1();
void output2();
void ins();
void down(int root,int size);
void up();
void heap();
int judge1();
int judge2();
int main()
{
	scanf("%d", &N);
	for (int i = 0; i < N; i++)
	{
		scanf("%d", &before1[i]);
		before2[i] = before1[i];
	}
	for (int i = 0; i < N; i++)
	{
		scanf("%d", &later[i]);
	}
	//if (later[N - 1] == before[N - 1])
	//{
	//	printf("Insertion Sort\n");
	//	ins();
	//}//当前认为：后面的数不变的是插入排序,存疑
	//else
	//{
	//	printf("Heap Sort\n");
	//	heap();
	//}
	ins();
	heap();
	return 0;
}
void output1()
{
	for (int i = 0; i < N; i++)
	{
		if (i == 0)
		{
			printf("%d", before1[i]);
		}
		else
		{
			printf(" %d", before1[i]);
		}
	}
}
void output2()
{
	for (int i = 0; i < N; i++)
	{
		if (i == 0)
		{
			printf("%d", before2[i]);
		}
		else
		{
			printf(" %d", before2[i]);
		}
	}
}
int judge1()//判断是否排序到给定状态
{
	int ret = 0;
	for (int i = 0; i < N; i++)
	{
		if (before1[i] != later[i])
		{
			ret = 1;
			break;
		}
	}
	return ret;
}
int judge2()//判断是否排序到给定状态
{
	int ret = 0;
	for (int i = 0; i < N; i++)
	{
		if (before2[i] != later[i])
		{
			ret = 1;
			break;
		}
	}
	return ret;
}
void ins()
{
	int flag = 0;
	for (int i = 1; i < N; i++)
	{
		for (int j = i; j > 0; j--)
		{
			if (before1[j] < before1[j - 1])
			{
				int temp = before1[j - 1];
				before1[j - 1] = before1[j];
				before1[j] = temp;
			}
		}
		//output(); printf("\n");
		if (flag == 1)
		{
			printf("Insertion Sort\n");
			output1();
			break;
		}
		if (!judge1())
		{
			flag = 1;
		}
	}
}
void down(int root,int size)
{
	int dad = root, kid = root * 2 + 1;
	while (kid <= size)
	{
		if (kid + 1 < size && before2[kid] < before2[kid + 1])
		{
			kid++;
		}
		if (before2[dad] < before2[kid])
		{
			int temp = before2[dad];
			before2[dad] = before2[kid];
			before2[kid] = temp;
		}
		else break;
		dad = kid;
		kid = dad * 2 + 1;
	}
}
void up()
{
	/*for (int i = 1; i < N; i++)
	{
		int kid = i;
		int dad = (kid - 1) / 2;
		while (before[kid] > before[dad])
		{
			int temp = before[kid];
			before[kid] = before[dad];
			before[dad] = temp;

			kid = dad;
			dad = (kid - 1) / 2;
		}
	}*/
	for (int i = N / 2; i >= 0; i--)
	{
		down(i, N -1);
	}
}
void heap()
{
	int flag = 0;
	int size = N - 1;
	up();
	//output(); printf("\n");
	while (size >= 1)
	{
		int max = before2[0];
		before2[0] = before2[size];
		before2[size] = max;
		size--;
		down(0, size);
		//output(); printf("\n");
		if (flag == 1)
		{
			printf("Heap Sort\n");
			output2();
			break;
		}
		if (!judge2())
		{
			flag = 1;
		}
	}
}