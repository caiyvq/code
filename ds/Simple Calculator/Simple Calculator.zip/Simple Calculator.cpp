﻿#include<stdio.h>
#include<stdlib.h>

#define EMPTY -1
typedef struct numStack NUM;
typedef struct opStack OP;
struct numStack
{
	int top;
	int *num;
};
struct opStack
{
	int top;
	char *op;
}*sop;

void pushNum(NUM *s,int x);
void pushOp(OP *s, char c);
int popNum(NUM *s);
char popOp(OP *s);
bool isEmpty(OP *s);
int main()
{
	int N;
	int x;
	char c;
	scanf("%d", &N);
	NUM* snum = (NUM*)malloc(sizeof(struct numStack));
	sop = (OP*)malloc(sizeof(struct opStack));
	snum->num = (int*)malloc(sizeof(int) * 1001);
	sop->op = (char*)malloc(sizeof(char) * 1001);
	snum->top = EMPTY;
	sop->top = EMPTY;

	for (int i = 0; i < N; i++)
	{
		scanf("%d", &x);
		pushNum(snum, x);
	}
	getchar();
	for (int i = 0; i < N-1; i++)
	{
		scanf("%c", &c);
		getchar();
		pushOp(sop, c);
	}
	//打印snum
	/*for (int i = 0; i <= snum->top; i++)
	{
		printf("%d ", snum->num[i]);
	}
	printf("\n");*/
	bool flag = false;
	int n1, n2;
	char c1;
	while (!isEmpty(sop))
	{
		n1 = popNum(snum);
		n2 = popNum(snum);
		c1 = popOp(sop);
		switch (c1)
		{
		case '+':n2 = n2 + n1; break;
		case '-':n2 = n2 - n1; break;
		case '*':n2 = n2 * n1; break;
		case '/':
			if (n1 == 0)
			{
				flag = true;
				sop->top = EMPTY;
				break;
			}
			else
			{
				n2 = n2 / n1;
			}
		}
		pushNum(snum, n2);
	}
	if (flag)
	{
		printf("ERROR: %d/0", n2);
	}
	else
	{
		printf("%d", popNum(snum));
	}
	
}
bool isEmpty(OP *s)
{
	bool ret = false;
	if (s->top == EMPTY)
	{
		ret = true;
	}
	return ret;
}
void pushNum(NUM *s, int x)
{
	s->num[++s->top] = x;
}
void pushOp(OP *s, char c)
{
	s->op[++s->top] = c;
}
int popNum(NUM *s)
{
	int ret = s->num[s->top--];
	return ret;
}
char popOp(OP *s)
{
	char ret = s->op[s->top--];
	return ret;
}