﻿#include<stdio.h>
#include<stdlib.h>
const int max = 510;
const int minData = -1;
typedef struct EDGE edge;
struct EDGE
{
	int v1, v2;
	int weight;
	int eqaul;
	int del;
};
typedef struct HEAP heap;
struct HEAP
{
	int cap;
	struct EDGE e[max];
	int size;
}h;
int N, M;
int S[max];
void Union(int a,int b);
int Find(int a);
edge min();
void insert(int x);
int MST();

int main()
{
	scanf("%d %d", &N, &M);
	h.size = 0;
	h.cap = N;
	h.e[0].weight = minData;
	for (int i = 1; i <= N; i++)
	{
		S[i] = -1;
	}
	for (int i = 1; i <= M; i++)
	{
		scanf("%d %d %d", &h.e[i].v1, &h.e[i].v2, &h.e[i].weight);
		h.e[i].eqaul = 0;
		h.e[i].del = 0;
		insert(h.e[i].weight);
	}
	for (int i = 1; i <= M; i++)
	{
		for (int j = i+1; j <= M; j++)
		{
			if (h.e[i].weight == h.e[j].weight)
			{
				h.e[j].del = 1;
			}
		}
	}
	int flag = 0, sum = 0;
	while (h.size >= 0)
	{
		edge E = min();
		while (E.del == 1)E = min();
		
		if (S[Find(E.v1)] == -N)
		{
			flag = 1;
			break;
		}
		if (Find(E.v1) == Find(E.v2))continue;
		else
		{
			Union(Find(E.v1), Find(E.v2));
			sum += E.weight;
		}
	}
	if (flag == 0)
	{
		int cnt = 0;
		printf("No MST\n");
		for (int i = 1; i <= N; i++)
		{
			if (S[i] <= 0)
			{
				cnt++;
			}
		}
		printf("%d\n", cnt);
	}
	else
	{
		printf("%d\nNo", sum);
	}
}
void Union(int a,int b)
{
	if (S[a] <= S[b])
	{
		S[a] += S[b];
		S[b] = a;
	}
	else
	{
		S[b] += S[a];
		S[a] = b;
	}
}
int Find(int a)
{
	if (S[a] <= 0)return a;
	else return S[a] = Find(S[a]);
}
edge min()
{
	int i = 0, child = 0;
	edge minElem = h.e[1];
	edge lastElem = h.e[h.size--];

	for (i = 1; i * 2 <= h.size; i = child)
	{
		child = i * 2;
		if (child != h.size && h.e[child].weight > h.e[child + 1].weight)
		{
			child++;
		}
		if (lastElem.weight > h.e[child].weight)
		{
			h.e[i] = h.e[child];
		}
		else break;
	}
	h.e[i] = lastElem;
	return minElem;
}
void insert(int x)
{
	int i=0;
	for (i = ++h.size; h.e[i / 2].weight > x; i /= 2)
	{
		h.e[i] = h.e[i / 2];
	}
	h.e[i].weight = x;
}
int MST()
{
	int flag = 0, sum = 0;
	while (h.size >= 0)
	{
		edge E = min();
		if (S[Find(E.v1)] == -N)
		{
			flag = 1;
			break;
		}
		if (Find(E.v1) == Find(E.v2))continue;
		else
		{
			Union(Find(E.v1), Find(E.v2));
			sum += E.weight;
		}
	}
	return sum;
}